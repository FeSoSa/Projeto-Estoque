import java.util.HashMap

fun main(args:Array<String>){

    var user=HashMap<String,Int>()
    user.put("Felipe",123)
    user.put("Matheus",456)

}