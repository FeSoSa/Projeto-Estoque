package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.lang.System.console


class menu : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        val recebe = intent
        val parametro = recebe.extras
        var usuario = parametro!!.getString("nome")

        if (usuario != null) {
            usuario = "${usuario[0].uppercase()}${usuario.substring(1)}"
        }
        val titulo:TextView = findViewById(R.id.titulo)
        titulo.text = "Bem vindo ${usuario}"

        //botao de sair
        val sair: Button = findViewById(R.id.sair)
        sair.setOnClickListener {
            val login = Intent(this,MainActivity::class.java)
            startActivity(login)
        }

        val qrScanner: Button = findViewById(R.id.lerqrcode)
        qrScanner.setOnClickListener {
            val usuario = Bundle()
            usuario.putString("nome", usuario.toString())
            val qrview = Intent(this,Qrview::class.java)
            qrview.putExtras(usuario)
            startActivity(qrview)
        }


    }
}