package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.adapter.AdapterProduto

private val produto = HashMap<String, String>()

class Result : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        produto["7894900010015"] = "REFRIGERANTE COCA-COLA LATA 350ML|RA|RA-N1|RA-N1-1A|1000"
        produto["7894900011517"] = "REFRIGERANTE COCA-COLA GARRAFA 2L|RA|RA-N1|RA-N1-2A|1000"
        produto["7891991000833"] =
            "REFRIGERANTE SODA LIMONADA ANTARTIC LATA 350ML|RA|RA-N1|RA-N1-3A|1000"
        produto["7891991011020"] =
            "REFRIGERANTE GUARANA ANTARCTICA LATA 350ML|RA|RA-N2|RA-N2-1A|1000"
        produto["7898712836870"] = "REFRIGERANTE GUARANA ANTARCTICA 2L|RA|RA-N2|RA-N2-2A|1000"
        produto["7894900039924"] = "REFRIGERANTE FANTA LARANJA 2L|RA|RA-N2|RA-N2-3A|1000"
        produto["7894900031201"] = "REFRIGERANTE FANTA LARANJA LATA 350ML|RA|RA-N2|RA-N2-4A|1000"
        produto["7892840800079"] = "REFRIGERANTE PEPSI LATA 350ML|RA|RA-N3|RA-N3-1A|1000"
        produto["7892840813017"] = "REFRIGERANTE PEPSI 2L|RA|RA-N3|RA-N3-2A|1000"
        produto["7896004000855"] = "SUCRILHOS KELLOGG'S ORIGINAL 250G|RB|RB-N1|RB-N1-1A|1000"
        produto["7896004003979"] = "SUCRILHOS KELLOGG'S CHOCOLATE 320G|RB|RB-N1|RB-N1-2A|1000"
        produto["7896110005140"] =
            "PAPEL HIGIÊNICO PERSONAL FOLHA SIMPLES NEUTRO 60 METROS 4 UNIDADES|RB|RB-N2|RB-N2-1A|1000"
        produto["7896104998953"] = "PAPEL HIGIÊNICO MILI 4R|RB|RB-N2|RB-N2-2A|1000"
        produto["7896076002146"] = "PAPEL HIGIENICO DAMA 60MTR|RB|RB-N2|RB-N2-3A|1000"
        produto["7896276060021"] = "ARROZ AGULHINHA ARROZAL T1 5KG|RC|RC-N1|RC-N1-1A|1000"
        produto["7898295150189"] = "ARROZ SABOROSO 5KG|RC|RC-N1|RC-N1-2A|1000"
        produto["7896086423030"] = "ARROZ TRIMAIS 5KG|RC|RC-N1|RC-N1-3A|1000"
        produto["7896864400192"] = "FEIJAO PICININ 1KG|RC|RC-N2|RC-N2-1A|1000"
        produto["7897924800877"] = "FEIJAO PRETO VENEZA 1KG|RC|RC-N2|RC-N2-2A|1000"
        produto["7898084090030"] = "FEIJÃO PEREIRA CARIOQUINHA 1KG|RC|RC-N2|RC-N2-3A|1000"
        produto["7891959004415"] = "AÇUCAR REFINADO DOÇULA 1KG|RD|RD-N1|RD-N1-1A|1000"
        produto["7896032501010"] = "AÇÚCAR REFINADO DA BARRA 1KG|RD|RD-N1|RD-N1-2A|1000"
        produto["7896109801005"] = "AÇÚCAR REFINADO ESPECIAL GUARANI 1KG|RD|RD-N1|RD-N1-3A|1000"
        produto["7896319420546"] = "ACUCAR REFINADO CLARION 1KG|RD|RD-N2|RD-N2-1A|1000"
        produto["7896089028935"] =
            "CAFÉ TORRADO MOÍDO POUCHE CAFÉ DO PONTO 500G|RD|RD-N2|RD-N2-2A|1000"
        produto["7898286200077"] = "CAFE MARATA 500G|RD|RD-N2|RD-N2-3A|1000"
        produto["7891910010905"] = "CAFE CABOCLO 500G|RD|RD-N3|RD-N3-1A|1000"
        produto["7898079250012"] = "CAFE FIORENZA 500G|RD|RD-N3|RD-N3-2A|1000"
        produto["7891107000504"] = "OLEO DE SOJA SOYA 1L|RE|RE-N1|RE-N1-1A|1000"
        produto["7896334200550"] = "OLEO DE SOJA GRANOL 1L|RE|RE-N2|RE-N2-1A|1000"
        produto["7896036090107"] = "OLEO DE SOJA VELEIRO 1L|RE|RE-N3|RE-N3-1A|1000"

        val inten = intent
        val param = inten.extras
        var itens = param!!.getString("itens").toString()
        var usuario = param!!.getString("nome").toString()
        val reclyclerview_result: RecyclerView = findViewById(R.id.listaResult)
        val btn = findViewById<Button>(R.id.inicio)

        btn.setOnClickListener {
            val envia = Bundle()
            envia.putString("nome", usuario)
            val menu = Intent(this, menu::class.java)
            menu.putExtras(envia)
            startActivity(menu)
        }
        reclyclerview_result.layoutManager = LinearLayoutManager(this)
        reclyclerview_result.setHasFixedSize(true)

        val listaProdutos: MutableList<ProdutoL> = mutableListOf()
        val adapterProduto = AdapterProduto(this, listaProdutos)
        reclyclerview_result.adapter = adapterProduto
        var c = 0
        val lista = separar(itens)
        for (a in lista) {
            val listaB = separaProd(lista,c)
            val key = lista.keys.elementAt(c)
            val col = lista.getValue(key).toInt()
            val res = listaB[4].toInt() - col
            val produto1 = ProdutoL(
                "${listaB[0]}",
                "$key",
                col,
                res
            )
            listaProdutos.add(produto1)
            c++
        }
    }
    private fun separaProd(separa: HashMap<String, String>, c: Int): List<String> {
        val valor: String
        val chave = separa.keys.elementAt(c)
        valor = produto.getValue(chave).toString()
        return valor.split('|')
    }
    private fun separar(resultado: String): HashMap<String, String> {
        val Aresultado = resultado.split('|')
        val Bresultado = HashMap<String, String>()
        for (aux2 in Aresultado) {
            val aux = aux2.split(":")
            Bresultado[aux[0]] = aux[1]
        }
        return Bresultado
    }
}