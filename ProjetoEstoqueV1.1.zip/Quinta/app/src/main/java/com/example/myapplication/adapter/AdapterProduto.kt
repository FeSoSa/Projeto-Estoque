package com.example.myapplication.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.ProdutoL
import com.example.myapplication.R

class AdapterProduto(private val context:Context,private val produtos:MutableList<ProdutoL>): RecyclerView.Adapter<AdapterProduto.ProdutoViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProdutoViewHolder {
        val itemLista = LayoutInflater.from(context).inflate(R.layout.result_list_item,parent,false)
        val holder = ProdutoViewHolder(itemLista)
        return holder
    }

    override fun onBindViewHolder(holder: ProdutoViewHolder, position: Int) {
        holder.nomeProd.text=produtos[position].nomeProd
        holder.ean.text=produtos[position].Ean
        holder.coletado.text= produtos[position].Coletado.toString()
        holder.restante.text= produtos[position].Restante.toString()
    }

    override fun getItemCount(): Int = produtos.size

    inner class ProdutoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val nomeProd = itemView.findViewById<TextView>(R.id.nomeProd)
        val ean = itemView.findViewById<TextView>(R.id.Ean)
        val coletado = itemView.findViewById<TextView>(R.id.Coletado)
        val restante = itemView.findViewById<TextView>(R.id.Restante)


    }
}