package com.example.myapplication

data class ProdutoL(
    val nomeProd:String,
    val Ean:String,
    val Coletado:Int,
    val Restante:Int
)
