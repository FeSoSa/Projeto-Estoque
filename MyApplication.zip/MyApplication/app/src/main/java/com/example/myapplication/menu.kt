package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView


class menu : AppCompatActivity() {


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        //Titulo de entrada e parametros da 1ªtela
        val recebe = intent
        val parametros = recebe.extras
        val user = parametros!!.getString("nome")
        val titulo_menu:TextView=findViewById(R.id.welcome)
        titulo_menu.text="Bem vindo ${user}"

        //botao de sair
        val sair: Button = findViewById(R.id.sair)
        sair.setOnClickListener {
            val login = Intent(this,qrview::class.java)
            startActivity(login)
        }

        val qrScanner: Button = findViewById(R.id.lerqrcode)
        qrScanner.setOnClickListener {
            val qrview = Intent(this,qrview::class.java)
            startActivity(qrview)
        }


    }
}