package com.example.myapplication

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Looper
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.budiyev.android.codescanner.*
import com.example.myapplication.databinding.ActivityMainBinding
import com.google.zxing.Result


private const val CAMERA_REQUEST_CODE = 101

class Qrview : AppCompatActivity() {
    private lateinit var codeScanner: CodeScanner
    private lateinit var list: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private val listItem = ArrayList<String>()
    private val exibe = ArrayList<String>()
    val produto = HashMap<String, String>()
    private lateinit var binding: ActivityMainBinding

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_qrview)


        val scannerView = findViewById<CodeScannerView>(R.id.scanner_view)
        val list: ListView = findViewById(R.id.list)
        val qrDesc = findViewById<TextView>(R.id.qrDesc)
        setupPermissions()
        codeScanner = CodeScanner(this, scannerView)


        /*Lista de Produtos*/
        produto["7894900010015"] = "REFRIGERANTE COCA-COLA LATA 350ML|RA|RA-N1|1|1000"
        produto["7894900011517"] = "REFRIGERANTE COCA-COLA GARRAFA 2L|RA|RA-N1|2|1000"
        produto["7891991000833"] = "REFRIGERANTE SODA LIMONADA ANTARTIC LATA 350ML|RA|RA-N1|3|1000"
        produto["7891991011020"] = "REFRIGERANTE GUARANA ANTARCTICA LATA 350ML|RA|RA-N2|1|1000"
        produto["7898712836870"] = "REFRIGERANTE GUARANA ANTARCTICA 2L|RA|RA-N2|2|1000"
        produto["7894900039924"] = "REFRIGERANTE FANTA LARANJA 2L|RA|RA-N2|3|1000"
        produto["7894900031201"] = "REFRIGERANTE FANTA LARANJA LATA 350ML|RA|RA-N2|4|1000"
        produto["7892840800079"] = "REFRIGERANTE PEPSI LATA 350ML|RA|RA-N3|1|1000"
        produto["7892840813017"] = "REFRIGERANTE PEPSI 2L|RA|RA-N3|2|1000"
        produto["7896004000855"] = "SUCRILHOS KELLOGG'S ORIGINAL 250G|RB|RA-N1|1|1000"
        produto["7896004003979"] = "SUCRILHOS KELLOGG'S CHOCOLATE 320G|RB|RA-N1|2|1000"
        produto["7896110005140"] =
            "PAPEL HIGIÊNICO PERSONAL FOLHA SIMPLES NEUTRO 60 METROS 4 UNIDADES|RB|RA-N2|1|1000"
        produto["7896104998953"] = "PAPEL HIGIÊNICO MILI 4R|RB|RA-N2|2|1000"
        produto["7896076002146"] = "PAPEL HIGIENICO DAMA 60MTR|RB|RA-N2|3|1000"
        produto["7896276060021"] = "ARROZ AGULHINHA ARROZAL T1 5KG|RC|RA-N1|1|1000"
        produto["7898295150189"] = "ARROZ SABOROSO 5KG|RC|RA-N1|2|1000"
        produto["7896086423030"] = "ARROZ TRIMAIS 5KG|RC|RA-N1|3|1000"
        produto["7896864400192"] = "FEIJAO PICININ 1KG|RC|RA-N2|1|1000"
        produto["7897924800877"] = "FEIJAO PRETO VENEZA 1KG|RC|RA-N2|2|1000"
        produto["7898084090030"] = "FEIJÃO PEREIRA CARIOQUINHA 1KG|RC|RA-N2|3|1000"
        produto["7891959004415"] = "AÇUCAR REFINADO DOÇULA 1KG|RD|RA-N1|1|1000"
        produto["7896032501010"] = "AÇÚCAR REFINADO DA BARRA 1KG|RD|RA-N1|2|1000"
        produto["7896109801005"] = "AÇÚCAR REFINADO ESPECIAL GUARANI 1KG|RD|RA-N1|3|1000"
        produto["7896319420546"] = "ACUCAR REFINADO CLARION 1KG|RD|RA-N2|1|1000"
        produto["7896089028935"] = "CAFÉ TORRADO MOÍDO POUCHE CAFÉ DO PONTO 500G|RD|RA-N2|2|1000"
        produto["7898286200077"] = "CAFE MARATA 500G|RD|RA-N2|3|1000"
        produto["7891910010905"] = "CAFE CABOCLO 500G|RD|RA-N3|1|1000"
        produto["7898079250012"] = "CAFE FIORENZA 500G|RD|RA-N3|2|1000"
        produto["7891107000504"] = "OLEO DE SOJA SOYA 1L|RE|RA-N1|1|1000"
        produto["7896334200550"] = "OLEO DE SOJA GRANOL 1L|RE|RA-N2|1|1000"
        produto["7896036090107"] = "OLEO DE SOJA VELEIRO 1L|RE|RA-NW3|1|1000"

        // Parametros do QRCODE
        codeScanner.camera = CodeScanner.CAMERA_BACK // or CAMERA_FRONT or specific camera id
        codeScanner.formats = CodeScanner.ALL_FORMATS // list of type BarcodeFormat,
        // ex. listOf(BarcodeFormat.QR_CODE)
        codeScanner.autoFocusMode = AutoFocusMode.SAFE // or CONTINUOUS
        codeScanner.scanMode = ScanMode.SINGLE // or CONTINUOUS or PREVIEW
        codeScanner.isAutoFocusEnabled = true // Whether to enable auto focus or not
        codeScanner.isFlashEnabled = false // Whether to enable flash or not

        codeScanner.errorCallback = ErrorCallback { // or ErrorCallback.SUPPRESS
            runOnUiThread {
                Toast.makeText(
                    this, "Camera initialization error: ${it.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        scannerView.setOnClickListener {
            codeScanner.startPreview()
        }
        NovaLeitura()
    }

    private fun NovaLeitura() {
        codeScanner.decodeCallback = DecodeCallback {
            runOnUiThread {
                val resultado: String = it.text
                iniciar(resultado)
            }
        }
    }

    /*Funções*/

    private fun iniciar(resultado: String) {
        val separa = separar(resultado)
        val produto = escreveLista(separa)
        var c = 1
        box(produto, separa, c)
    }

    private fun box(produto: ArrayList<String>, separa: HashMap<String, String>, c: Int) {
        var b = 0
        var msg = ""



        for (a in produto) {
            val num = (separa.keys.elementAt(b))
            val envia = separa.getValue(num)
            msg += "${produto.get(b)} \n ${envia} Unidades\n\n"
            b++
        }
        AlertDialog.Builder(this)
            .setMessage("${msg}")
            .setTitle("Deseja escolher esses produtos?")
            .setPositiveButton("Sim", DialogInterface.OnClickListener { dialogInterface, i ->
                atualizaLista(produto)
                caminho(separa)
            })
            .setNegativeButton("Não", DialogInterface.OnClickListener { dialogInterface, i ->
                Toast.makeText(applicationContext, "Cancelado", Toast.LENGTH_SHORT).show()
                limpa()
                codeScanner.decodeCallback = DecodeCallback {
                    runOnUiThread {
                        val resultado: String = it.text
                        iniciar(resultado)
                    }
                }
            })
            .create()
            .show()

    }

    private fun caminho(separa: HashMap<String, String>) {
        var c = 0
        val qrDesc: TextView = findViewById(R.id.qrDesc)
        for (a in separa) {
            val conteudo = separaProd(separa, c)
            qrDesc.setText("Siga para a rua ${conteudo.get(1).last()}")
            codeScanner.startPreview()
            codeScanner.decodeCallback = DecodeCallback {
                val resultado = it
                FuncRua(resultado,conteudo,c)
            }
        c++
        }
    }
    private fun FuncRua(resultado: Result, conteudo: List<String>, c: Int) {
            val qrDesc: TextView = findViewById(R.id.qrDesc)
        if (resultado.text.toString() != conteudo.get(1)) {
            runOnUiThread {
                Toast.makeText(applicationContext, "Rua Errada!", Toast.LENGTH_SHORT).show()

            }
        } else if (resultado.text.toString() == conteudo.get(1)) {
            runOnUiThread {
                if (Looper.myLooper() == null)
                    Looper.prepare();
                Toast.makeText(applicationContext, "Rua Certa!", Toast.LENGTH_SHORT).show()
                val prateleira = conteudo.get(3).last()
                qrDesc.setText("Siga para a prateleira numero ${prateleira}")
                codeScanner.startPreview()
                codeScanner.decodeCallback = DecodeCallback {
                    val resultado = it
                    FuncPrat(resultado,conteudo,c)
                }

            }
        }
    }

    private fun FuncPrat(resultado: Result, conteudo: List<String>, c: Int) {
        val qrDesc: TextView = findViewById(R.id.qrDesc)
        if (resultado.text.toString() != conteudo.get(2)) {
            runOnUiThread {
                Toast.makeText(applicationContext, "Prateleira Errada!", Toast.LENGTH_SHORT).show()

            }
        } else if (resultado.text.toString() == conteudo.get(2)) {
            runOnUiThread {
                if (Looper.myLooper() == null)
                    Looper.prepare();
                Toast.makeText(applicationContext, "Prateleira Certa!", Toast.LENGTH_SHORT).show()
                qrDesc.setText("Siga para o Andar numero ${conteudo.get(3)}")
                codeScanner.startPreview()
                codeScanner.decodeCallback = DecodeCallback {
                    val resultado = it
                    FuncAnd(resultado,conteudo,c)
                }

            }
        }
    }

    private fun FuncAnd(resultado: Result, conteudo: List<String>, c: Int) {
        val qrDesc: TextView = findViewById(R.id.qrDesc)
        if (resultado.text.toString() != conteudo.get(3)) {
            runOnUiThread {
                Toast.makeText(applicationContext, "Andar Errado", Toast.LENGTH_SHORT).show()

            }
        } else if (resultado.text.toString() == conteudo.get(4)) {
            runOnUiThread {
                if (Looper.myLooper() == null)
                    Looper.prepare();
                Toast.makeText(applicationContext, "Andar Certo!", Toast.LENGTH_SHORT).show()
                qrDesc.setText("Escaneie o Produto ${conteudo.get(3)}")
                codeScanner.startPreview()
                codeScanner.decodeCallback = DecodeCallback {
                    val resultado = it
                    FuncAnd(resultado,conteudo,c)
                }

            }
        }
    }

    private fun separar(resultado: String): HashMap<String, String> {
        val Aresultado = resultado.split('|')
        val Bresultado = HashMap<String, String>()
        for (aux2 in Aresultado) {
            val aux = aux2.split(":")
            Bresultado[aux[0]] = aux[1]
        }
        return Bresultado
    }

    private fun escreveLista(Bresultado: HashMap<String, String>): ArrayList<String> {
        var b = 0
        for (a in Bresultado) {

            val num = (Bresultado.keys.elementAt(b))
            val envia = produto.getValue(num)
            val title = separaNome(envia)
            listItem.add(title)
            exibe.add(title)
            b++
        }
        return (listItem)
    }

    private fun atualizaLista(produto: ArrayList<String>) {
        var list: ListView = findViewById(R.id.list)
        adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, produto)
        list.setAdapter(adapter)
    }

    private fun limpa() {
        listItem.clear()
    }

    private fun separaNome(prod: String): String {
        val split = prod.split("|")
        val title = split.first()
        return title
    }

    private fun separaProd(separa: HashMap<String, String>, c: Int): List<String> {
        var c = 0
        var valor = ""
        val chave = separa.keys.elementAt(c)
        valor = produto.getValue(chave).toString()
        val conteudo = valor.split('|')
        return conteudo
    }

    /*Funções do QrCode*/
    override fun onResume() {
        super.onResume()
        codeScanner.startPreview()
    }

    override fun onPause() {
        codeScanner.releaseResources()
        super.onPause()
    }

    private fun setupPermissions() {
        val permission = ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.CAMERA
        )

        if (permission != PackageManager.PERMISSION_GRANTED) {
            makeRequest()
        }
    }

    private fun makeRequest() {
        ActivityCompat.requestPermissions(
            this, arrayOf(android.Manifest.permission.CAMERA),
            CAMERA_REQUEST_CODE
        )
    }

    @SuppressLint("MissingSuperCall")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        when (requestCode) {
            CAMERA_REQUEST_CODE -> {
                if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(
                        this,
                        "Você precisa da permissão da camera para poder usar",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    //sucesso
                }
            }
        }
    }

}

