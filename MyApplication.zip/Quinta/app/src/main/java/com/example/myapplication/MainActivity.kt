package com.example.myapplication

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.SearchManager
import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import java.util.*

class MainActivity : AppCompatActivity() {


    val usuarios = HashMap<String, Int>()

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nome: EditText = findViewById(R.id.txtLogin)
        val senha: EditText = findViewById(R.id.txtSenha)

        //Botao de Login
        val entrar: Button = findViewById(R.id.entrar)
        entrar.setOnClickListener({
            autenticar(nome, senha)

        })

        //Login e senha dos usuarios
        usuarios["felipe"] = 290103
        usuarios["matheus"] = 50795
        usuarios["deriel"] = 101001
        usuarios["rodrigo"] = 70301
        usuarios["giovani"] = 456789
        usuarios["a"]=0
    }
    //
    private fun autenticar(nome: EditText, senha: EditText) {
        if (nome.text.toString().isBlank() || senha.text.toString().isBlank()){
            Toast.makeText(applicationContext,"Campos em branco!",Toast.LENGTH_SHORT).show()
        }else{
        val nomeA = nome.text.toString().lowercase()
        if (usuarios.containsKey(nomeA)) {
            if (senha.text.toString().toInt() == usuarios.getValue("${nomeA}")){
            val usuario = Bundle()
            usuario.putString("nome", nome.text.toString())

            val menu = Intent(this, menu::class.java)
            menu.putExtras(usuario)
            startActivity(menu)
        }else{
            Toast.makeText(applicationContext,"Usuario ou senha incorretos!",Toast.LENGTH_SHORT).show()
        }}else{
            Toast.makeText(applicationContext,"Usuario ou senha incorretos",Toast.LENGTH_SHORT).show()
        }
    }}
}



