package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Looper
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.budiyev.android.codescanner.*
import com.example.myapplication.databinding.ActivityMainBinding


private const val CAMERA_REQUEST_CODE = 101

@Suppress("NAME_SHADOWING")
class QrviewPos : AppCompatActivity() {
    private lateinit var codeScanner: CodeScanner
    private lateinit var list: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private val listItem = ArrayList<String>()
    private val exibe = ArrayList<String>()
    private val produto = HashMap<String, String>()
    private lateinit var binding: ActivityMainBinding

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_qrview)


        val scannerView = findViewById<CodeScannerView>(R.id.scanner_view)
        findViewById<TextView>(R.id.qrDesc)
        setupPermissions()
        codeScanner = CodeScanner(this, scannerView)


        /*Lista de Produtos*/
        produto["7894900010015"] = "REFRIGERANTE COCA-COLA LATA 350ML|RA|RA-N1|RA-N1-1A|1000"
        produto["7894900011517"] = "REFRIGERANTE COCA-COLA GARRAFA 2L|RA|RA-N1|RA-N1-2A|1000"
        produto["7891991000833"] =
            "REFRIGERANTE SODA LIMONADA ANTARTIC LATA 350ML|RA|RA-N1|RA-N1-3A|1000"
        produto["7891991011020"] =
            "REFRIGERANTE GUARANA ANTARCTICA LATA 350ML|RA|RA-N2|RA-N2-1A|1000"
        produto["7898712836870"] = "REFRIGERANTE GUARANA ANTARCTICA 2L|RA|RA-N2|RA-N2-2A|1000"
        produto["7894900039924"] = "REFRIGERANTE FANTA LARANJA 2L|RA|RA-N2|RA-N2-3A|1000"
        produto["7894900031201"] = "REFRIGERANTE FANTA LARANJA LATA 350ML|RA|RA-N2|RA-N2-4A|1000"
        produto["7892840800079"] = "REFRIGERANTE PEPSI LATA 350ML|RA|RA-N3|RA-N3-1A|1000"
        produto["7892840813017"] = "REFRIGERANTE PEPSI 2L|RA|RA-N3|RA-N3-2A|1000"
        produto["7896004000855"] = "SUCRILHOS KELLOGG'S ORIGINAL 250G|RB|RB-N1|RB-N1-1A|1000"
        produto["7896004003979"] = "SUCRILHOS KELLOGG'S CHOCOLATE 320G|RB|RB-N1|RB-N1-2A|1000"
        produto["7896110005140"] =
            "PAPEL HIGIÊNICO PERSONAL FOLHA SIMPLES NEUTRO 60 METROS 4 UNIDADES|RB|RB-N2|RB-N2-1A|1000"
        produto["7896104998953"] = "PAPEL HIGIÊNICO MILI 4R|RB|RB-N2|RB-N2-2A|1000"
        produto["7896076002146"] = "PAPEL HIGIENICO DAMA 60MTR|RB|RB-N2|RB-N2-3A|1000"
        produto["7896276060021"] = "ARROZ AGULHINHA ARROZAL T1 5KG|RC|RC-N1|RC-N1-1A|1000"
        produto["7898295150189"] = "ARROZ SABOROSO 5KG|RC|RC-N1|RC-N1-2A|1000"
        produto["7896086423030"] = "ARROZ TRIMAIS 5KG|RC|RC-N1|RC-N1-3A|1000"
        produto["7896864400192"] = "FEIJAO PICININ 1KG|RC|RC-N2|RC-N2-1A|1000"
        produto["7897924800877"] = "FEIJAO PRETO VENEZA 1KG|RC|RC-N2|RC-N2-2A|1000"
        produto["7898084090030"] = "FEIJÃO PEREIRA CARIOQUINHA 1KG|RC|RC-N2|RC-N2-3A|1000"
        produto["7891959004415"] = "AÇUCAR REFINADO DOÇULA 1KG|RD|RD-N1|RD-N1-1A|1000"
        produto["7896032501010"] = "AÇÚCAR REFINADO DA BARRA 1KG|RD|RD-N1|RD-N1-2A|1000"
        produto["7896109801005"] = "AÇÚCAR REFINADO ESPECIAL GUARANI 1KG|RD|RD-N1|RD-N1-3A|1000"
        produto["7896319420546"] = "ACUCAR REFINADO CLARION 1KG|RD|RD-N2|RD-N2-1A|1000"
        produto["7896089028935"] =
            "CAFÉ TORRADO MOÍDO POUCHE CAFÉ DO PONTO 500G|RD|RD-N2|RD-N2-2A|1000"
        produto["7898286200077"] = "CAFE MARATA 500G|RD|RD-N2|RD-N2-3A|1000"
        produto["7891910010905"] = "CAFE CABOCLO 500G|RD|RD-N3|RD-N3-1A|1000"
        produto["7898079250012"] = "CAFE FIORENZA 500G|RD|RD-N3|RD-N3-2A|1000"
        produto["7891107000504"] = "OLEO DE SOJA SOYA 1L|RE|RE-N1|RE-N1-1A|1000"
        produto["7896334200550"] = "OLEO DE SOJA GRANOL 1L|RE|RE-N2|RE-N2-1A|1000"
        produto["7896036090107"] = "OLEO DE SOJA VELEIRO 1L|RE|RE-N3|RE-N3-1A|1000"

        // Parametros do QRCODE
        codeScanner.camera = CodeScanner.CAMERA_BACK // or CAMERA_FRONT or specific camera id
        codeScanner.formats = CodeScanner.ALL_FORMATS // list of type BarcodeFormat,
        // ex. listOf(BarcodeFormat.QR_CODE)
        codeScanner.autoFocusMode = AutoFocusMode.SAFE // or CONTINUOUS
        codeScanner.scanMode = ScanMode.SINGLE // or CONTINUOUS or PREVIEW
        codeScanner.isAutoFocusEnabled = true // Whether to enable auto focus or not
        codeScanner.isFlashEnabled = false // Whether to enable flash or not

        codeScanner.errorCallback = ErrorCallback { // or ErrorCallback.SUPPRESS
            runOnUiThread {
                Toast.makeText(
                    this, "Camera initialization error: ${it.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        scannerView.setOnClickListener {
            codeScanner.startPreview()
        }

        val recebe = intent
        val parametro = recebe.extras
        val c = parametro!!.getInt("num")
        val listaC = parametro.getString("lista")
        val resultado = listaC.toString()


        val separa = separar(resultado)
        val produto = escreveLista(separa)
        atualizaLista(produto)
        if (listaC != null) {
            caminho(separa, c, listaC)
        }
    }

    @SuppressLint("SetTextI18n")
    private fun caminho(separa: HashMap<String, String>, c: Int, listaC: String) {

        val qrDesc: TextView = findViewById(R.id.qrDesc)
        val conteudo = separaProd(separa, c)
        var resultado: String

        qrDesc.text = "Siga para a rua ${conteudo[1].last()}"
        val key = separa.keys.elementAt(c)
        codeScanner.startPreview()
        codeScanner.decodeCallback = DecodeCallback { it ->
            resultado = it.toString()
            if (resultado != conteudo[1]) {
                runOnUiThread {
                    Toast.makeText(applicationContext, "Rua Errada!", Toast.LENGTH_SHORT).show()
                }
            } else if (resultado == conteudo[1]) {
                val prateleira = conteudo[2].last()
                qrDesc.text = "Siga para a prateleira numero $prateleira"


                codeScanner.startPreview()
                codeScanner.decodeCallback = DecodeCallback { it ->
                    resultado = it.toString()
                    if (resultado != conteudo[2]) {
                        runOnUiThread {
                            Toast.makeText(
                                applicationContext,
                                "Prateleira Errada!",
                                Toast.LENGTH_SHORT
                            )
                                .show()

                        }
                    } else {
                        val andar = conteudo[3].substring(6, 7).first()
                        qrDesc.text = "Siga para o ${andar}º Andar"
                        codeScanner.startPreview()
                        codeScanner.decodeCallback = DecodeCallback { it ->
                            resultado = it.toString()
                            if (resultado != conteudo[3]) {
                                runOnUiThread {
                                    Toast.makeText(
                                        applicationContext,
                                        "Andar Errado",
                                        Toast.LENGTH_SHORT
                                    )
                                        .show()

                                }
                            } else {
                                qrDesc.text = "Escaneie o Produto ${separa.getValue(key)} vezes"

                                val uni = separa.getValue(key).toInt()
                                var cont = 0
                                for (a in cont..uni) {
                                    codeScanner.startPreview()
                                    codeScanner.decodeCallback = DecodeCallback {
                                        resultado = it.toString()
                                        if (resultado != key) {
                                            runOnUiThread {
                                                if (Looper.myLooper() == null)
                                                    Looper.prepare()
                                                Toast.makeText(
                                                    applicationContext,
                                                    "Produto Errado!",
                                                    Toast.LENGTH_SHORT
                                                )
                                                    .show()
                                            }
                                        } else {
                                            cont++
                                            qrDesc.text = "Escaneie o Produto ${cont}/${uni}"

                                            if (cont == uni) {
                                                runOnUiThread {
                                                    if (Looper.myLooper() == null)
                                                        Looper.prepare()
                                                    Toast.makeText(
                                                        applicationContext,
                                                        "Produtos Coletados",
                                                        Toast.LENGTH_SHORT
                                                    ).show()
                                                }
                                                if (separa.size - 1 == c) {
                                                    val fim = Bundle()
                                                    val msg = finalizar(listaC)
                                                    fim.putString("msg", msg)
                                                    val Resultview = Intent(
                                                        this, Result::class.java
                                                    )
                                                    Resultview.putExtras(fim)
                                                    startActivity(Resultview)

                                                } else {
                                                    var c2 = c
                                                    c2++
                                                    val pos2 = Bundle()
                                                    pos2.putInt("num", c2)
                                                    pos2.putString("key", key)
                                                    pos2.putString("lista", listaC)
                                                    val qrviewA =
                                                        Intent(this, QrviewPos::class.java)
                                                    qrviewA.putExtras(pos2)
                                                    startActivity(qrviewA)
                                                    // }
                                                }
                                            }
                                        }

                                    }

                                }
                            }


                        }
                    }


                }
            }


        }
    }

    private fun finalizar(listaF: String): String {
        val listan = separar(listaF)
        var msg = ""
        var d=0
        for (a in listan) {
            val key = (listan.keys.elementAt(d))
            val valor = listan.getValue(key)
            val valor2 = separaProd(listan,d)
            val resto = valor2.get(4).toInt() - valor.toInt()
            msg += "${valor2.get(0)} \n $valor Unidades Coletadas\n $resto Unidades restantes\n Ean13:$key\n---------------\n"
            d++
        }
        return msg
    }

    private fun separar(resultado: String): HashMap<String, String> {
        val Aresultado = resultado.split('|')
        val Bresultado = HashMap<String, String>()
        for (aux2 in Aresultado) {
            val aux = aux2.split(":")
            Bresultado[aux[0]] = aux[1]
        }
        return Bresultado
    }

    private fun escreveLista(Bresultado: HashMap<String, String>): ArrayList<String> {
        var b = 0
        for (a in Bresultado) {

            val num = (Bresultado.keys.elementAt(b))
            val envia = produto.getValue(num)
            val title = separaNome(envia)
            listItem.add(title)
            exibe.add(title)
            b++
        }
        return (listItem)
    }

    private fun atualizaLista(produto: ArrayList<String>) {
        val list: ListView = findViewById(R.id.list)
        adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, produto)
        list.adapter = adapter
    }

    private fun separaNome(prod: String): String {
        val split = prod.split("|")
        return split.first()
    }

    private fun separaProd(separa: HashMap<String, String>, c: Int): List<String> {
        val valor: String
        val chave = separa.keys.elementAt(c)
        valor = produto.getValue(chave).toString()
        return valor.split('|')
    }

    /*Funções do QrCode*/
    override fun onResume() {
        super.onResume()
        codeScanner.startPreview()
    }

    override fun onPause() {
        codeScanner.releaseResources()
        super.onPause()
    }

    private fun setupPermissions() {
        val permission = ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.CAMERA
        )

        if (permission != PackageManager.PERMISSION_GRANTED) {
            makeRequest()
        }
    }

    private fun makeRequest() {
        ActivityCompat.requestPermissions(
            this, arrayOf(android.Manifest.permission.CAMERA),
            CAMERA_REQUEST_CODE
        )
    }

    @SuppressLint("MissingSuperCall")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        when (requestCode) {
            CAMERA_REQUEST_CODE -> {
                if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(
                        this,
                        "Você precisa da permissão da camera para poder usar",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    //sucesso
                }
            }
        }
    }


}
