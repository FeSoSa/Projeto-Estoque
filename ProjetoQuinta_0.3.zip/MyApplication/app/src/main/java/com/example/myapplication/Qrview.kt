package com.example.myapplication

import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.budiyev.android.codescanner.*


private const val CAMERA_REQUEST_CODE = 101

class Qrview : AppCompatActivity() {
    private lateinit var codeScanner: CodeScanner
    private lateinit var list: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private val listItem = ArrayList<String>()
    val produto = HashMap<String, String>()


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_qrview)
        val scannerView = findViewById<CodeScannerView>(R.id.scanner_view)
        val list:ListView = findViewById(R.id.list)
        val qrDesc = findViewById<TextView>(R.id.qrDesc)
        setupPermissions()
        codeScanner = CodeScanner(this, scannerView)
          produto["7894900010015"] = "REFRIGERANTE COCA-COLA LATA 350ML|A|1|1|1000"
          produto["7894900011517"] = "REFRIGERANTE COCA-COLA GARRAFA 2L|A|1|2|1000"
          produto["7891991000833"] = "REFRIGERANTE SODA LIMONADA ANTARTIC LATA 350ML|A|1|3|1000"
          produto["7891991011020"] = "REFRIGERANTE GUARANA ANTARCTICA LATA 350ML|A|2|1|1000"
        produto["7898712836870"] = "REFRIGERANTE GUARANA ANTARCTICA 2L|A|2|2|1000"
        produto["7894900039924"] = "REFRIGERANTE FANTA LARANJA 2L|A|2|3|1000"
        produto["7894900031201"] = "REFRIGERANTE FANTA LARANJA LATA 350ML|A|2|4|1000"
        produto["7892840800079"] = "REFRIGERANTE PEPSI LATA 350ML|A|3|1|1000"
        produto["7892840813017"] = "REFRIGERANTE PEPSI 2L|A|3|2|1000"
        produto["7896004000855"] = "SUCRILHOS KELLOGG'S ORIGINAL 250G|B|1|1|1000"
        produto["7896004003979"] = "SUCRILHOS KELLOGG'S CHOCOLATE 320G|B|1|2|1000"
        produto["7896110005140"] =
            "PAPEL HIGIÊNICO PERSONAL FOLHA SIMPLES NEUTRO 60 METROS 4 UNIDADES|B|2|1|1000"
        produto["7896104998953"] = "PAPEL HIGIÊNICO MILI 4R|B|2|2|1000"
        produto["7896076002146"] = "PAPEL HIGIENICO DAMA 60MTR|B|2|3|1000"
        produto["7896276060021"] = "ARROZ AGULHINHA ARROZAL T1 5KG|C|1|1|1000"
        produto["7898295150189"] = "ARROZ SABOROSO 5KG|C|1|2|1000"
        produto["7896086423030"] = "ARROZ TRIMAIS 5KG|C|1|3|1000"
        produto["7896864400192"] = "FEIJAO PICININ 1KG|C|2|1|1000"
        produto["7897924800877"] = "FEIJAO PRETO VENEZA 1KG|C|2|2|1000"
        produto["7898084090030"] = "FEIJÃO PEREIRA CARIOQUINHA 1KG|C|2|3|1000"
        produto["7891959004415"] = "AÇUCAR REFINADO DOÇULA 1KG|D|1|1|1000"
        produto["7896032501010"] = "AÇÚCAR REFINADO DA BARRA 1KG|D|1|2|1000"
        produto["7896109801005"] = "AÇÚCAR REFINADO ESPECIAL GUARANI 1KG|D|1|3|1000"
        produto["7896319420546"] = "ACUCAR REFINADO CLARION 1KG|D|2|1|1000"
        produto["7896089028935"] = "CAFÉ TORRADO MOÍDO POUCHE CAFÉ DO PONTO 500G|D|2|2|1000"
        produto["7898286200077"] = "CAFE MARATA 500G|D|2|3|1000"
        produto["7891910010905"] = "CAFE CABOCLO 500G|D|3|1|1000"
        produto["7898079250012"] = "CAFE FIORENZA 500G|D|3|2|1000"
        produto["7891107000504"] = "OLEO DE SOJA SOYA 1L|E|1|1|1000"
        produto["7896334200550"] = "OLEO DE SOJA GRANOL 1L|E|2|1|1000"
        produto["7896036090107"] = "OLEO DE SOJA VELEIRO 1L|E|3|1|1000"

        // Parameters (default values)
        codeScanner.camera = CodeScanner.CAMERA_BACK // or CAMERA_FRONT or specific camera id
        codeScanner.formats = CodeScanner.ALL_FORMATS // list of type BarcodeFormat,
        // ex. listOf(BarcodeFormat.QR_CODE)
        codeScanner.autoFocusMode = AutoFocusMode.SAFE // or CONTINUOUS
        codeScanner.scanMode = ScanMode.SINGLE // or CONTINUOUS or PREVIEW
        codeScanner.isAutoFocusEnabled = true // Whether to enable auto focus or not
        codeScanner.isFlashEnabled = false // Whether to enable flash or not

        // Callbacks
        codeScanner.decodeCallback = DecodeCallback {
            runOnUiThread {

                val resultado: String = it.text
                iniciar(resultado)
                separar(resultado);
            }
        }
        codeScanner.errorCallback = ErrorCallback { // or ErrorCallback.SUPPRESS
            runOnUiThread {
                Toast.makeText(
                    this, "Camera initialization error: ${it.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        scannerView.setOnClickListener {
            codeScanner.startPreview()
        }

    }

    private fun iniciar(resultado: String) {

    }

    private fun separar(resultado: String) {

        val Aresultado = resultado.split('|')
        val Bresultado = HashMap<String, String>()
        val ArrayResult = ArrayList<String>()
        for (aux2 in Aresultado) {
            val aux = aux2.split(":")
            Bresultado[aux[0]] = aux[1]
        }
        escreveLista(Bresultado)
    }

    /* a variavel Bresultado ja ta retornando separado a chave e a quantidade dos itens, só tem que achar uma maneira de
    * conseguir pegar a chave dentro do array para colocar o nome na lista da tela*/
    private fun escreveLista(Bresultado: HashMap<String, String>) {
        var list:ListView = findViewById(R.id.list)
        var b=0
        for (a in Bresultado) {

            val num = (Bresultado.keys.elementAt(b))
            val envia = produto.getValue(num)
            val title = separaProd(envia)
            listItem.add(title)
            adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listItem)
            list.setAdapter(adapter)

            b++
        }
    }

    private fun separaProd(prod: String): String {
        val split = prod.split("|")
        val title = split.first()
        return title
    }

    override fun onResume() {
        super.onResume()
        codeScanner.startPreview()
    }

    override fun onPause() {
        codeScanner.releaseResources()
        super.onPause()
    }

    private fun setupPermissions() {
        val permission = ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.CAMERA
        )

        if (permission != PackageManager.PERMISSION_GRANTED) {
            makeRequest()
        }
    }

    private fun makeRequest() {
        ActivityCompat.requestPermissions(
            this, arrayOf(android.Manifest.permission.CAMERA),
            CAMERA_REQUEST_CODE
        )
    }

    @SuppressLint("MissingSuperCall")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        when (requestCode) {
            CAMERA_REQUEST_CODE -> {
                if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(
                        this,
                        "Você precisa da permissão da camera para poder usar",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    //sucesso
                }
            }
        }
    }

    /* Outras funções*/


}

