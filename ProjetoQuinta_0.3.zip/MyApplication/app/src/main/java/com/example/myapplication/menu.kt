package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button


class menu : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        //botao de sair
        val sair: Button = findViewById(R.id.sair)
        sair.setOnClickListener {
            val login = Intent(this,MainActivity::class.java)
            startActivity(login)
        }

        val qrScanner: Button = findViewById(R.id.lerqrcode)
        qrScanner.setOnClickListener {
            val qrview = Intent(this,Qrview::class.java)
            startActivity(qrview)
        }


    }
}